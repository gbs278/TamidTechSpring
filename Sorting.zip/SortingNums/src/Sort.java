
public class Sort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

	}
	public static void sorter(int[] given) {
		// loop through the first int, then the second, and so on
		for(int x=0; x<given.length; x++) {
			// loop through all ints after x 
			for(int y=x+1; y<given.length; y++) {
				// compare to see which is greatest
				if(given[y] < given[x]) {
					// if the int at y is less than x, such the two of them
					int temp = given[x];
					given[x] = given[y];
					given[y] = temp;
				}
			}
		}
		
	}

}
